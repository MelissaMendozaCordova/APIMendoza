<?php

use App\Http\Controllers\Api\ConsultingroomsController;
use App\Http\Controllers\Api\DoctorsController;
use App\Http\Controllers\Api\PatientController;
use App\Http\Controllers\Api\QuotesController;
use App\Http\Controllers\Api\SpecialtiesController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::get('/specialties', [SpecialtiesController::class,'list']);
Route::get('/consultingrooms', [ConsultingroomsController::class,'list']);
Route::get('/quotes', [QuotesController::class,'list']);
Route::get('/doctors', [DoctorsController::class,'list']);
Route::get('/patients', [PatientController::class,'list']);

Route::get('/specialties/{id}', [SpecialtiesController::class,'getbyid']);
Route::get('/consultingrooms/{id}', [ConsultingroomsController::class,'getbyid']);
Route::get('/quotes/{id}', [QuotesController::class,'getbyid']);
Route::get('/doctors/{id}', [DoctorsController::class,'getbyid']);
Route::get('/patients/{id}', [PatientController::class,'getbyid']);

Route::post('/consultingrooms/create', [ConsultingroomsController::class,'create']);
Route::post('/specialties/create', [SpecialtiesController::class,'create']);
Route::post('/quotes/create', [QuotesController::class,'create']);
Route::post('/doctors/create', [DoctorsController::class,'create']);
Route::post('/patients/create', [PatientController::class,'create']);

Route::post('/consultingrooms/update', [ConsultingroomsController::class,'update']);
Route::post('/specialties/update', [SpecialtiesController::class,'update']);
Route::post('/quotes/update', [QuotesController::class,'update']);
Route::post('/doctors/update', [DoctorsController::class,'update']);
Route::post('/patients/update', [PatientController::class,'update']);











