<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\quotes;

class QuotesController extends Controller
{
    
    public function list(){
        $brands =quotes::all();
        $list = [];

        foreach($brands as $brand){
            $object = [
                "id" => $brand->id ,
                "quotes" => $brand->quotes,
                "consultingroom" => $brand->consultingroom,
                "patient" => $brand->patient,
                "folio" => $brand->folio,
                "doctor" => $brand->doctor,
                "date" => $brand->date,
            ];
                array_push($list, $object);
        }
        return response()->json($list);
    }
    public function getbyid($id){
    $patiente = quotes::where('id','=',$id)->first();

        $object = [
            "id" => $patiente->id,
            "patient" => $patiente->patient];
    
    return response()->json($object);
}
public function create(request $request){
    $data = $request->validate([
        'quotes'=>'required|min3',
        'consultingroom'=>'required|min1|max3',
        'patient'=>'required|min3',
        'folio'=>'required|min5' ,
        'doctor'=> 'required|min3',
        'date'=> 'required',
    ]);

    $quote=quotes::create([
        'patient'=>$data['patient'],
    ]);

    if($quote){
        return response()->json([
            'message'=>'ToFine',
            'data'=> $quote
        ]);
    }else{
        return response()->json([
            'message'=> 'ToMal'
        ]);
    }
}
public function update(Request $request){
    $data = $request->validate([
        'id'=> 'required|integer|min:1',
        'quotes'=>'required|min3',
        'consultingroom'=>'required|min1|max3',
        'patient'=>'required|min3',
        'folio'=>'required|min5' ,
        'doctor'=> 'required|min3',
        'date'=> 'required',
    ]);

    $brand = quotes::where('id','=',$data['id'])->first();

    if($brand){
        $old = $brand;
        $brand->quotes=$data['quotes'];
        $brand->consultingroom=$data['consultingroom'];
        $brand->patient=$data['patient'];
        $brand->folio=$data['folio'];
        $brand->doctor=$data['doctor'];
        $brand->date=$data['date'];

        
        if($brand->save()){
            $object = [
                "response" =>'TodoFinolis',
                "old" => $old,
                "new" => $brand,
                ];
            return response()->json($object);
    }else{
    $object = [
        "response" =>'TodoMal',
        "data" => $brand,
        ];
    return response()->json($object);}
}
}}


