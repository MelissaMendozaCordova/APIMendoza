<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Patient;
use Illuminate\Http\Request;

class PatientController extends Controller
{
    public function list(){
        $brands =Patient::all();
        $list = [];

        foreach($brands as $brand){
            $object = [
                "id" => $brand->id ,
                "name" => $brand->name,
                "lastname" => $brand->lastname,
                "folio" => $brand->folio,
                "phonenumber" => $brand->phonenumber,
            ];
                array_push($list, $object);
        }
        return response()->json($list);
    }
    public function getbyid($id){
    $patient = Patient::where('id','=',$id)->first();

        $object = [
            "id" => $patient->id,
            "patient" => $patient->name];    
    return response()->json($object);
}
public function create(request $request){
    $data = $request->validate([
        'name'=>'required|min3,max55' ,
        'lastname'=>'required|min3,max60' ,
        'folio'=>'required|numeric' ,
        'phonenumber'=>'required|numeric' ,

    ]);

    $patientes=Patient::create([
        'name'=>$data['name'],
        'lastname'=>$data['lastname'],
        'folio'=>$data['folio'],
        'phonenumber'=>$data['phonenumber'],
    ]);

    if($patientes){
        return response()->json([
            'message'=>'ToFine',
            'data'=> $patientes
        ]);
    }else{
        return response()->json([
            'message'=> 'ToMal'
        ]);
    }
}
public function update(Request $request){
    $data = $request->validate([
        'id'=> 'required|integer|min:1',
        'name'=>'required|min0|max55',
        'lastname'=>'required|min3|max60',
        'folio'=>'required|numeric',
        'phonenumber'=>'required|numeric',
        ]);


    $brand = Patient::where('id','=',$data['id'])->first();

    if($brand){
        $old = $brand;
        $brand->name=$data['name'];
        $brand->lastname=$data['lastname'];
        $brand->folio=$data['folio'];
        $brand->phonenumber=$data['phonenumber'];
        
        if($brand->save()){
            $object = [
                "response" =>'TodoFinolis',
                "old" => $old,
                "new" => $brand,
                ];
            return response()->json($object);
    }else{
    $object = [
        "response" =>'TodoMal',
        "data" => $brand,
        ];
    return response()->json($object);}
}
}}


