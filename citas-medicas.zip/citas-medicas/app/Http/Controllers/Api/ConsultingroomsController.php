<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Consultingrooms;
use Illuminate\Http\Request;

class ConsultingroomsController extends Controller

    
    {  public function list(){
        $brands = Consultingrooms::all();
        $list = [];

        foreach($brands as $brand){
            $object = [
                "id" => $brand->id,
                "numero" => $brand->number,];
                array_push($list, $object);
        }
        return response()->json($list);
    }
    public function getbyid($id){
    $numero = Consultingrooms::where('id','=',$id)->first();
    
        $object = [
            "id" => $numero->id,
            "numero" => $numero->number];
    
    return response()->json($object);
    }
    public function create(Request $request){
        $data = $request->validate([
            'numero'=>'required|numeric|min:1|max:10' ,
        ]);

        $consultingrooms=Consultingrooms::create([
            'numero'=>$data['numero']
        ]);

        if($consultingrooms){
            return response()->json([
                'message'=>'ToFine',
                'data'=> $consultingrooms
            ]);
        }else{
            return response()->json([
                'message'=> 'ToMal'
            ]);
        }
    }
    public function update(Request $request){
        $data = $request->validate([
            'id'=> 'required|integer|min:1',
            'numero'=> 'required|numeric|min:1|max:10',
            ]);


        $brand = Consultingrooms::where('id','=',$data['id'])->first();

        if($brand){
            $old = $brand;
            $brand->numero=$data['numero'];
            
            if($brand->save()){
                $object = [
                    "response" =>'TodoFinolis',
                    "old" => $old,
                    "new" => $brand,
                    ];
                return response()->json($object);
        }else{
        $object = [
            "response" =>'TodoMal',
            "data" => $brand,
            ];
        return response()->json($object);}
    }
}}

