<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Doctor;
use Illuminate\Http\Request;

class DoctorsController extends Controller
{
    public function list(){
        $brands =Doctor::all();
        $list = [];

        foreach($brands as $brand){
            $object = [
                "id" => $brand->id ,
                "name" => $brand->name,
                "lastname" => $brand->lastname,
                "speciality" => $brand->speciality,
                "entrytime" => $brand->entrytime,
                "depuratetime" => $brand->depuratetime,
            ];
                array_push($list, $object);
        }
        return response()->json($list);
    }
    public function getbyid($id){
    $doctor = Doctor::where('id','=',$id)->first();
        $object = [
            "id" => $doctor->id,
            "name" => $doctor->name,
            "lastname" => $doctor->lastname,
            "speciality" => $doctor->speciality,
            "entrytime" => $doctor->entrytime,
            "depuratetime" => $doctor->depuratetime];
    
    return response()->json($object);
}
public function create(request $request){
    $data = $request->validate([
        'name'=>'required|min0|max55' ,
        'lastname'=>'required|min3|max60' ,
        'speciality'=>'required|min3|max60' ,
        'entrytime'=>'required' ,
        'depuratetime'=>'required' ,

    ]);

    $doctors=Doctor::create([
        'name'=>$data['name'],
        'lastname'=>$data['lastname'],
        'speciality'=>$data['speciality'],
        'entrytime'=>$data['entrytime'],
        'depuratetime'=>$data['depuratetime'],

    ]);

    if($doctors){
        return response()->json([
            'message'=>'ToFine',
            'data'=> $doctors
        ]);
    }else{
        return response()->json([
            'message'=> 'ToMal'
        ]);
    }
}
public function update(Request $request){
    $data = $request->validate([
        'id'=> 'required|integer|min:1',
        'name'=>'required|min0|max55' ,
        'lastname'=>'required|min3|max60' ,
        'speciality'=>'required|min3|max60' ,
        'entrytime'=>'required|numeric' ,
        'depuratetime'=>'required|numeric',
        ]);


    $brand = Doctor::where('id','=',$data['id'])->first();

    if($brand){
        $old = $brand;
        $brand->name=$data['name'];
        $brand->lastname=$data['lastname'];
        $brand->speciality=$data['speciality'];
        $brand->entrytime=$data['entrytime'];
        $brand->depuratetime=$data['depuratetime'];

        
        if($brand->save()){
            $object = [
                "response" =>'TodoFinolis',
                "old" => $old,
                "new" => $brand,
                ];
            return response()->json($object);
    }else{
    $object = [
        "response" =>'TodoMal',
        "data" => $brand,
        ];
    return response()->json($object);}
}
}}
