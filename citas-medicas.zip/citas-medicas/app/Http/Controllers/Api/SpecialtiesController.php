<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Specialties;
use Illuminate\Http\Request;

class SpecialtiesController extends Controller
{
    public function list(){
        $brands = Specialties::all();
        $list = [];

        foreach($brands as $brand){
            $object = [
                "id" => $brand->id,
                "specialty" => $brand->specialty,];
                array_push($list, $object);
        }
        return response()->json($list);
    }
    public function getbyid($id){
    $specialties = Specialties::where('id','=',$id)->first();

        $object = [
            "id" => $specialties->id,
            "especialidad" => $specialties->specialty];
    
    return response()->json($object);
}
public function create(request $request){
    $data = $request->validate([
        'specialty'=>'required|min1' ,
    ]);

    $speciality=Specialties::create([
        'specialty'=>$data['specialty'],
    ]);

    if($speciality){
        return response()->json([
            'message'=>'ToFine',
            'data'=> $speciality
        ]);
    }else{
        return response()->json([
            'message'=> 'ToMal'
        ]);
    }
}

}
